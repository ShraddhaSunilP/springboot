package com.luv2code.SpringBootRestController;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestControllerApplicationTests {

	@Test
	void contextLoads() {
	}

}
